import React, { createContext, useContext, useState, useCallback } from 'react';
import { Modal, ModalType } from '../components/Modal';

interface IModalProps {
  title: string;
  type: ModalType;
  content?: any;

  icon?: any;

  cdPlano?: string;
  numFuncionalidade?: number;
  onSend?: () => Promise<void>;
}

interface IModalContext {
  toggleModal: () => void;
  openModal: (props: IModalProps) => void;
  closeModal: () => void;
}

const ModalContext = createContext<IModalContext | null>(null);

export const ModalProvider: React.FC = ({ children }) => {
  const [Opened, setOpened] = useState(false);
  const [Content, setContent] = useState(null);
  const [Title, setTitle] = useState('');
  const [CdPlano, setCdPlano] = useState('');
  const [NumFuncionalidade, setNumFuncionalidade] = useState(null);
  const [OnSend, setOnSend] = useState(null);
  const [Type, setType] = useState<ModalType>(null);
  const [Icon, setIcon] = useState<ModalType>(null);

  const toggleModal = useCallback(() => {
    setOpened((opened) => !opened);
  }, []);

  const openModal = useCallback(({ title, type, content, icon, cdPlano, numFuncionalidade, onSend }) => {
    setTitle(title);
    setContent(content);
    setType(type);
    setOpened(true);

    setCdPlano(cdPlano);
    setNumFuncionalidade(numFuncionalidade);
    setOnSend(() => onSend);

    if (icon) setIcon(icon);

    document.getElementsByTagName('body')[0].style.overflow = 'hidden';
  }, []);

  const closeModal = useCallback(() => {
    setOpened(false);

    document.getElementsByTagName('body')[0].style.overflow = 'auto';
  }, []);

  return (
    <ModalContext.Provider value={{ toggleModal, openModal, closeModal }}>
      {Opened && (
        <Modal
          title={Title}
          type={Type}
          content={Content}
          icon={Icon}
          onClose={closeModal}
          cdPlano={CdPlano}
          numFuncionalidade={NumFuncionalidade}
          onSend={OnSend}
        />
      )}

      {children}
    </ModalContext.Provider>
  );
};

export function useModal(): IModalContext {
  const context = useContext(ModalContext);

  if (!context) throw new Error('useModal must be used within a ModalProvider');

  return context;
}
