import React from "react";
import { ThemeProvider } from "styled-components";
import { ModalProvider } from "./modal";

interface WebUiProvider {
  theme: any;
}

export const WebUiProvider: React.FC<WebUiProvider> = ({ children, theme }) => {
  return (
    <ThemeProvider theme={theme}>
      <ModalProvider>{children}</ModalProvider>
    </ThemeProvider>
  );
};
