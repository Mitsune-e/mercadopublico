import { criarLog } from '@intech/react-log';
import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';

import { useHistory, useLocation } from 'react-router-dom';
import { SideMenuPage, WebArea, WebRoute } from '../../';
import { BloqueioService } from '../../services/BloqueioService';
import { useSession } from '../Session';

interface IMasterPageContext {
  navigate: (route: string) => void;
  title: (value: string) => void;
  getUsername: () => string;
  noPadding: (value: boolean) => void;
  showMenu: (value: boolean) => void;
  verifyBlock: (numFuncionalidade: number) => void;
}

const MasterPageContext = createContext<IMasterPageContext | null>(null);

interface IMasterPageProps {
  menuRoute: string;
  logo: any;
  version: string;
  routes: Array<WebArea | WebRoute>;
}

export const MasterPageProvider: React.FC<IMasterPageProps> = ({ menuRoute, logo, version, routes }) => {
  const history = useHistory();
  const location = useLocation();
  const session = useSession();

  const [Routes, setRoutes] = useState<Array<WebRoute | WebArea>>(routes);
  const [Title, setTitle] = useState('');
  const [ShowMenu, setShowMenu] = useState(true);

  const [Admin, setAdmin] = useState(false);
  const [Username, setUsername] = useState('');
  const [NoPadding, setNoPadding] = useState(false);
  const [Blocked, setBlocked] = useState(false);

  useEffect(() => {
    setRoutes(routes);
  }, [routes]);

  useEffect(() => {
    (async () => {
      setBlocked(false);

      let user = await session.getUser();

      if (user) {
        setUsername(user.Nome);
        setAdmin(user.Admin);
      }
    })();
  }, [location.pathname]);

  const navigate = useCallback((route: string) => {
    history.push(route);
  }, []);

  const title = useCallback((value: string) => {
    setTitle(value);
  }, []);

  const getUsername = useCallback(() => Username, []);

  const noPadding = useCallback((value) => {
    setNoPadding(value);
  }, []);

  const showMenu = useCallback((value) => {
    setShowMenu(value);
  }, []);

  const verifyBlock = (numFuncionalidade: number) => {
    BloqueioService.Buscar(numFuncionalidade).then((bloqueio: boolean) => {
      setBlocked(bloqueio);
    });
  };

  return (
    <MasterPageContext.Provider value={{ navigate, title, getUsername, noPadding, showMenu, verifyBlock }}>
      <SideMenuPage
        admin={Admin}
        logo={logo}
        routes={Routes}
        username={Username}
        version={version}
        noPadding={NoPadding}
        title={Title}
        showMenu={ShowMenu}
        menuRoute={menuRoute}
        blocked={Blocked}
      />
    </MasterPageContext.Provider>
  );
};

interface IProps {
  title?: string;
  numFuncionalidade?: number;
  usaLog?: boolean;
  usaBloqueio?: boolean;
}

export function useMasterPage(props?: IProps): IMasterPageContext {
  const context = useContext(MasterPageContext);

  if (!context) throw new Error('useMasterPage must be user within a MasterPageProvider');

  if (props?.title) context.title(props.title);
  else context.title('');

  if (props?.usaLog) {
    criarLog(props.numFuncionalidade);
  }

  if (props?.usaBloqueio) {
    context.verifyBlock(props.numFuncionalidade);
  }

  return context;
}
