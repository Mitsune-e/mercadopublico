import React, { createContext, useCallback, useContext } from "react";
import { useHistory, useLocation } from "react-router-dom";
import axios from "axios";
import { Session } from "@intech/react-service";

interface ISessionContext {
  getUser: () => Promise<{ Admin: boolean; Nome: string; Pensionista: boolean; GrupoFamilia: boolean }>;
  getToken: () => Promise<string>;
}

const SessionContext = createContext<ISessionContext | null>(null);

interface ISessionProps {
  loginRoute: string;
  verifyTokenApiRoute: string;
}

export const SessionProvider: React.FC<ISessionProps> = ({ children, loginRoute, verifyTokenApiRoute }) => {
  const location = useLocation();
  const history = useHistory();

  const getUser = useCallback(async () => {
    try {
      let token = await Session.getToken();
      let { data } = await axios.get(verifyTokenApiRoute, { headers: { Authorization: `Bearer ${token}` } });

      return { Admin: data.Admin, Nome: data.Nome, Pensionista: data.Pensionista, GrupoFamilia: data.GrupoFamilia };
    } catch (err) {
      if (err.message.indexOf("401") > -1) {
        await Session.clear();
        history.push(loginRoute);
      } else {
        alert("Ops! Ocorreu um erro ao processar sua requisição.");
        console.error(err);
      }
    }

    return null;
  }, [location.pathname]);

  const getToken = useCallback(async () => {
    return await Session.getToken();
  }, []);

  return <SessionContext.Provider value={{ getUser, getToken }}>{children}</SessionContext.Provider>;
};

export function useSession(): ISessionContext {
  let context = useContext(SessionContext);

  if (!context) throw new Error("useSession must be user within a SessionProvider");

  return context;
}
