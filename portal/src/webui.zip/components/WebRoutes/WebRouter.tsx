import React from "react";
import { BrowserRouter, Switch, Route, HashRouter } from "react-router-dom";

import { WebArea, WebRoute } from "../..";

interface IProps {
  routes: Array<WebRoute | WebArea>;
  hashRouter?: boolean;
}

export const WebRouter: React.FC<IProps> = ({ routes, hashRouter }) => {
  function extractRoutes() {
    let result: WebRoute[] = [];

    for (const route of routes) {
      if (route instanceof WebRoute) result.push(route);

      if (route instanceof WebArea)
        for (const areaRoute of route.routes) result.push(areaRoute);
    }

    return result;
  }

  function content() {
    const routes = extractRoutes();

    return (
      <Switch>
        {routes.map((item, index: number) => {
          if (!item.externalLink) {
            return (
              <Route
                key={index}
                exact={item.exactPath}
                path={item.path}
                component={item.component}
              />
            );
          } else return null;
        })}
      </Switch>
    );
  }

  if (hashRouter) {
    return <HashRouter>{content()}</HashRouter>;
  } else {
    return <BrowserRouter>{content()}</BrowserRouter>;
  }
};
