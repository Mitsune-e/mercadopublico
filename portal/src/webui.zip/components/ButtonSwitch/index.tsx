import React from 'react';
import { FaCheck, FaTimes } from 'react-icons/fa';
import { Button, ButtonType } from '../Button';

interface IProps {
  checked?: boolean;

  activeTitle?: string;
  inactiveTitle?: string;
  activeType?: ButtonType;
  inactiveType?: ButtonType;

  icon?: any;
  activeIcon?: any;
  inactiveIcon?: any;
  iconRight?: boolean;
  className?: string;
  id?: string;

  disabled?: boolean;
  block?: boolean;

  onChange?: Function;
}

export const ButtonSwitch: React.FC<IProps> = ({
  activeIcon = <FaCheck />,
  inactiveIcon = <FaTimes />,

  activeType = 'primary',
  inactiveType = 'dark',

  activeTitle,
  inactiveTitle,

  checked,
  iconRight,

  onChange,

  className,
  id,
  ...rest
}) => {
  return (
    <Button
      id={id}
      onClick={onChange}
      type={checked ? activeType : inactiveType}
      title={checked ? activeTitle : inactiveTitle}
      icon={checked ? activeIcon : inactiveIcon}
      className={className}
      {...rest}
    />
  );
};
