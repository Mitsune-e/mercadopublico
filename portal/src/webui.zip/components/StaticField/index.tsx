import React from "react";
import classNames from "classnames";

import { Row, Label } from "../..";
import { LabelAlign, LabelPosition } from "../Label";
import { format, parseISO } from "date-fns";

export type StaticFieldType = "text" | "money" | "date" | "percent";

interface IProps {
  value: string | number | Date | undefined;

  title?: string;
  fieldSize?: number;
  mask?: "cpf";
  type?: StaticFieldType;
  inline?: boolean;

  labelSize?: number;
  labelPosition?: LabelPosition;
  labelClassName?: string;

  tooltip?: string;
  tooltipColor?: string;
  labelAlign?: LabelAlign;
  id?: string;
}

export const StaticField: React.FC<IProps> = ({
  value,

  title,
  type,
  inline,

  labelSize,
  labelPosition = "left",
  labelClassName,

  tooltip,
  tooltipColor,
  labelAlign = "right",
  id,
}) => {
  function parsePercent(val) {
    if (val === "NaN" || val === "" || val === undefined) val = "0,00";

    if (typeof val === "string")
      return `${parseFloat(val).toLocaleString("pt-br", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })}%`;
    else
      return `${val.toLocaleString("pt-br", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })}%`;
  }

  function parseMoney(val) {
    if (val === "NaN" || val === "") val = "0,00";

    if (typeof val === "string")
      return `R$ ${parseFloat(val).toLocaleString("pt-br", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })}`;
    else
      return `R$ ${val.toLocaleString("pt-br", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })}`;
  }

  function parseDate(val: Date | string | null) {
    try {
      var parsedVal: Date;

      if (typeof val === "string") parsedVal = parseISO(val);
      else parsedVal = val;

      if (val) return format(parsedVal, "dd/MM/yyyy");
      else return "-";
    } catch {
      return val;
    }
  }

  function parseValue() {
    var formattedValue: string | number | Date = "";

    if (value && value !== "") formattedValue = value;

    if (type === "date") return parseDate(formattedValue as Date | null);
    else if (type === "money") return parseMoney(formattedValue);
    else if (type === "percent") return parsePercent(formattedValue);

    return formattedValue;
  }

  function renderField() {
    let value: string | number | Date = parseValue();

    const labelClasses = classNames({
      col: title,
      "form-control-plaintext": title,
      "ml-1": labelPosition === "left",
    });

    return <div id={id} dangerouslySetInnerHTML={{ __html: value.toString() }} className={labelClasses} />;
  }

  const containerClassName = classNames("form-group", {
    "col-md": inline,
  });

  if (labelPosition === "up") {
    return (
      <div className={containerClassName}>
        {title && (
          <Label
            value={title}
            size={labelSize}
            labelPosition={labelPosition}
            className={labelClassName}
            tooltip={tooltip}
            tooltipColor={tooltipColor}
            labelAlign={labelAlign}
          />
        )}

        {renderField()}
      </div>
    );
  }

  if (title) {
    return (
      <div className={containerClassName}>
        <Row>
          {title && (
            <Label
              value={title}
              size={labelSize}
              labelPosition={labelPosition}
              className={labelClassName}
              tooltip={tooltip}
              tooltipColor={tooltipColor}
              labelAlign={labelAlign}
            />
          )}

          <div className={"col"}>{renderField()}</div>
        </Row>
      </div>
    );
  }

  return renderField();
};
