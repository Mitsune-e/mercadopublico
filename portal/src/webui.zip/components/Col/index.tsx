import React from "react";
import classNames from "classnames";

export interface IColProps {
  className?: string;
  children: React.ReactNode;
  id?: string;
}

export const Col: React.FC<IColProps> = ({ className, children, id }) => {
  var haveColClassName = className?.indexOf("col-") > -1;

  var classes = classNames({ col: !haveColClassName }, className);

  return (
    <div id={id} className={classes}>
      {children}
    </div>
  );
};
