import React from "react";
import { tomorrow } from "react-syntax-highlighter/dist/esm/styles/prism";
import { Container } from "./styles";

interface IProps {
  language?: string;
  id?: string;
}

export const Code: React.FC<IProps> = ({ language = "tsx", children, id }) => {
  return (
    <Container id={id} language={language} style={tomorrow} className={"mb-4 mt-4"} showLineNumbers wrapLines>
      {children}
    </Container>
  );
};
