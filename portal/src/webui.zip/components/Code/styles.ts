import styled from "styled-components";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";

export const Container = styled(SyntaxHighlighter)`
  & span {
    font-family: monospace !important;
    font-size: 10pt !important;
  }
`;