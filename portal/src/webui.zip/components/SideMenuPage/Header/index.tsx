import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { MenuButtonContainer, MenuButton, PageTitle, PageUser, PageNames, Container } from './styles';
import { FaBars } from 'react-icons/fa';
import { AdminButton } from './AdminButton';
import { WebArea, WebRoute } from '../../..';

interface IProps {
  username: string;
  admin: boolean;
  isMenuOpened: boolean;
  routes: Array<WebRoute | WebArea>;
  toggleMenu: any;

  title?: string;
}

export const Header: React.FC<IProps> = ({ routes, title, toggleMenu, username, admin }) => {
  const location = useLocation();

  const [Title, setTitle] = useState('');
  const [Routes, setRoutes] = useState<WebRoute[]>([]);

  useEffect(() => {
    if (routes && routes.length > 0) {
      let result: WebRoute[] = [];

      for (const route of routes) {
        if (route instanceof WebRoute) result.push(route);

        if (route instanceof WebArea) for (const areaRoute of route.routes) result.push(areaRoute);
      }

      setRoutes(result);
    }
  }, [routes]);

  useEffect(() => {
    if (title) {
      setTitle(title);
      return;
    }

    if (Routes && Routes.length > 0) {
      let routeName = location.pathname;

      for (let route of Routes) {
        if (routeName === route.path || routeName === route.linkPath || routeName.includes(route.linkPath)) {
          setTitle(route.title);
          return;
        }
      }
    }
  }, [location.pathname, title, Routes]);

  async function handleToggleMenu() {
    await toggleMenu();
  }

  return (
    <Container>
      <MenuButtonContainer>
        <MenuButton className="btn btn-link" onClick={handleToggleMenu}>
          <FaBars />
        </MenuButton>
      </MenuButtonContainer>

      <PageNames>
        <PageTitle>{Title}</PageTitle>

        <PageUser className={'text-right d-none d-sm-block'}>
          {username}

          <AdminButton admin={admin} />
        </PageUser>
      </PageNames>
    </Container>
  );
};
