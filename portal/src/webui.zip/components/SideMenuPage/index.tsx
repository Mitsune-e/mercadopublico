import React, { useCallback, useEffect, useState } from 'react';
import { Route, Switch, useLocation } from 'react-router-dom';
import axios from 'axios';
import { Session } from '@intech/react-service';
import { WebRoute, WebArea } from '../..';
import { Navbar } from './Navbar';
import { Header } from './Header';
import { Block, BlockTitle, PageWrapper, PageWrapperContent } from './styles';
import { FaBan } from 'react-icons/fa';
interface IProps {
  admin: boolean;
  username: string;
  logo: string;
  routes: Array<WebRoute | WebArea>;
  version: string;
  showMenu: boolean;
  menuRoute: string;
  blocked: boolean;

  title?: string;
  onLogout?: Function;
  noPadding?: boolean;
}

export const SideMenuPage: React.FC<IProps> = ({ admin, username, logo, routes, version, showMenu, title, noPadding, menuRoute, blocked }) => {
  const location = useLocation();
  const [MenuOpen, setMenuOpen] = useState(false);
  const [Routes, setRoutes] = useState([]);
  const [NavbarRoutes, setNavbarRoutes] = useState([]);

  useEffect(() => {
    (async () => {
      if (location.pathname == '/login') {
        setRoutes([routes.filter((x) => x.id === 'login')[0]]);
      } else {
        let token = await Session.getToken();
        let { data } = await axios.get(menuRoute, { headers: { Authorization: `Bearer ${token}` } });
        let menus = data;

        let routesList: WebRoute[] = [];
        let navbarRoutesList = [];

        for (const route of routes) {
          if (menus.includes(route.id) && route instanceof WebRoute) {
            routesList.push(route);
            navbarRoutesList.push(route);
          }
          if (menus.includes(route.id) && route instanceof WebArea) {
            let area = Object.assign<WebArea, any>(new WebArea(), route);
            area.routes = [];
            for (let areaRoute of route.routes) {
              if (menus.includes(areaRoute.id)) {
                routesList.push(areaRoute);
                area.routes.push(areaRoute);
              }
            }
            navbarRoutesList.push(area);
          }
        }

        setNavbarRoutes(navbarRoutesList);
        setRoutes(routesList);
      }
    })();
  }, [routes, location.pathname]);

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  const handleToggleMenu = useCallback(() => {
    setMenuOpen((old) => !old);
  }, [showMenu]);

  return (
    <>
      {showMenu && <Navbar logo={logo} routes={NavbarRoutes} version={version} isOpened={MenuOpen} toggleMenu={handleToggleMenu} />}

      <PageWrapper marginLeft={showMenu}>
        {showMenu && <Header isMenuOpened={MenuOpen} toggleMenu={handleToggleMenu} title={title} admin={admin} routes={routes} username={username} />}

        <PageWrapperContent noPadding={noPadding || !showMenu} headerHidden={!showMenu}>
          {blocked && (
            <Block>
              <FaBan size={100} />
              <BlockTitle>Funcionalidade bloqueada temporariamente.</BlockTitle>
            </Block>
          )}

          {!blocked && (
            <Switch>
              {Routes.map((item, index: number) => {
                if (!item.externalLink) {
                  return <Route key={index} exact={item.exactPath} path={item.path} component={item.component} />;
                } else return null;
              })}
            </Switch>
          )}
        </PageWrapperContent>
      </PageWrapper>
    </>
  );
};
