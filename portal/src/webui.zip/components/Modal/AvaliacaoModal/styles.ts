import styled from 'styled-components';

export const Container = styled.div`
  padding: 20px;
  position: relative;
  width: 700px;
  min-height: 300px;
  background: #fff;
  border-radius: 5px;
`;

export const AvaliacaoTitulo = styled.div`
  font-size: 20px;
  text-align: center;
`;

export const AvaliacaoNotas = styled.div`
  margin: 45px 0;
  text-align: center;
`;

export const AvaliacaoComentario = styled.div`
  textarea {
    width: 100%;
  }
`;

export const AvaliacaoConfirmar = styled.div`
  text-align: center;
`;
