import { Alert, Button, useModal } from '../../../';
import React, { useEffect, useState } from 'react';
import { AvaliacaoEntidade } from '../../../entities';
import { AvaliacaoService } from '../../../services';
import { AvaliacaoComentario, AvaliacaoConfirmar, AvaliacaoNotas, AvaliacaoTitulo, Container } from './styles';
import { FaPaperPlane, FaSpinner } from 'react-icons/fa';

interface IProps {
  onSend: () => Promise<void>;
  numFuncionalidade: number;
  cdPlano: string;
}

export const AvaliacaoModal: React.FC<IProps> = ({ numFuncionalidade, cdPlano, onSend }) => {
  const TOTAL_NOTA = Array.from({ length: 5 }, (_, i) => i + 1);

  const modal = useModal();

  const [Loading, setLoading] = useState(false);
  const [Erro, setErro] = useState('');

  const [Texto, setTexto] = useState('');
  const [Nota, setNota] = useState(0);
  const [Comentario, setComentario] = useState('');

  useEffect(() => {
    (async () => {
      console.log({ numFuncionalidade });
      if (numFuncionalidade) {
        setLoading(true);

        const texto = await AvaliacaoService.BuscarTexto(numFuncionalidade);
        setTexto(texto.TXT_TEXTO);

        setLoading(false);
      }
    })();
  }, [numFuncionalidade]);

  function handleChangeComentario(e: any) {
    setComentario(e.target.value);
  }

  async function handleEnviar() {
    try {
      if (Nota === 0) {
        alert('Por favor, escolha uma nota para a funcionalidade');
        return;
      }

      const avaliacao: AvaliacaoEntidade = {
        NUM_FUNCIONALIDADE: numFuncionalidade,
        NUM_NOTA: Nota,
        TXT_COMENTARIO: Comentario,
        CD_PLANO: cdPlano
      };

      await AvaliacaoService.Enviar(avaliacao);

      alert('Sua avaliação foi enviada com sucesso!');

      await onSend();

      modal.closeModal();
    } catch (e: any) {
      setErro(e);
    }
  }

  return (
    <Container>
      {Loading && (
        <div className="text-center">
          <div>
            <FaSpinner className="icon-spin" />
          </div>
          Carregando...
        </div>
      )}
      {!Loading && Erro && (
        <>
          <Alert type="danger">{Erro}</Alert>
        </>
      )}

      {!Loading && !Erro && (
        <>
          <AvaliacaoTitulo>
            <div dangerouslySetInnerHTML={{ __html: Texto }}></div>
          </AvaliacaoTitulo>

          <AvaliacaoNotas>
            <span className="mr-2">Ruim</span>
            {TOTAL_NOTA.map((nota: number, index: number) => (
              <Button
                key={index}
                title={nota.toString()}
                type={Nota === nota ? 'success' : 'default'}
                disabled={Nota === nota}
                className="mr-2"
                onClick={() => setNota(nota)}
              />
            ))}
            <span>Ótimo</span>
          </AvaliacaoNotas>

          <AvaliacaoComentario className="mb-2">Faça aqui um comentário, sugestão, elogio ou reclamação:</AvaliacaoComentario>

          <AvaliacaoComentario>
            <textarea value={Comentario} rows={5} onChange={handleChangeComentario} maxLength={100}></textarea>
          </AvaliacaoComentario>

          <AvaliacaoConfirmar>
            <Button title="Enviar" type="success" onClick={handleEnviar} icon={<FaPaperPlane />} usesLoading loadingText="Enviando..." />
          </AvaliacaoConfirmar>
        </>
      )}
    </Container>
  );
};
